//Adapter Implementing Target
//Responsibility adapting the Adaptee(EnemyRobo) according to the Targets(EnemyAttacker) need
public class EnemyRobotAdapter implements EnemyAttacker{

	EnemeyRobot theRobot;
	
	public EnemyRobotAdapter(EnemeyRobot newRobot)
	{
		theRobot=newRobot;
	}
	@Override
	public void fireWeapon()  
	{
		theRobot.smashWithHands();
		
	}

	@Override
	public void driveForward() {
		theRobot.walkForward();
		
	}

	@Override
	public void assignDriver(String driver)
	{
		theRobot.reactToHuman(driver);
		
	}

}
