
public class PlayWithRemote 
{
	public static void main(String[] args)
	{
		ElectronicDevice myDevice=TVRemote.getDevice();
		
		
		
		TurnOn onCommand=new TurnOn(myDevice);
		
		DeviceButton onPressed=new DeviceButton(onCommand);
		
		onPressed.press();
		
		System.out.println("---------Now-------------");
		TurnVolUp incrementVol=new TurnVolUp(myDevice);
		
		DeviceButton increaseVol=new DeviceButton(incrementVol);
		
		increaseVol.press();
		increaseVol.press();
		increaseVol.press();
		
		System.out.println("----------Now------------");
		
TurnVolDown decrementVol=new TurnVolDown(myDevice);
		
		DeviceButton decreaseVol=new DeviceButton(decrementVol);
		
		decreaseVol.press();
		decreaseVol.press();
		decreaseVol.press();
		
		TurnOff offCommand=new TurnOff(myDevice);
		
		DeviceButton offPressed=new DeviceButton(offCommand);
		
		offPressed.press();
		
		System.out.println("----------Now THE RADIO STARTS------------");
		ElectronicDevice myRadio=RadioRemote.getDevice();
		
		TurnOn onRadio=new TurnOn(myRadio);
		
		DeviceButton radioRemotePressed=new DeviceButton(onRadio);
		
		radioRemotePressed.press();
		
		System.out.println("----------Now THE RADIO Volume Increases------------");
		
		
		TurnVolUp incrementRadioVol=new TurnVolUp(myRadio);
		
		DeviceButton increaseRadioVol=new DeviceButton(incrementRadioVol);
		
		increaseRadioVol.press();
		increaseRadioVol.press();
		increaseRadioVol.press();
		
		System.out.println("----------Now RADIO Volume Decreases------------");
		
TurnVolDown decrementRadioVol=new TurnVolDown(myRadio);
		
		DeviceButton decreaseRadioVol=new DeviceButton(decrementRadioVol);
		
		decreaseRadioVol.press();
		decreaseRadioVol.press();
		decreaseRadioVol.press();
		
		System.out.println("----------Now RADIO would be off------------");
		
		TurnOff offRadio=new TurnOff(myRadio);
		
		DeviceButton radioRemotePressedAgain=new DeviceButton(offRadio);
		
		radioRemotePressedAgain.press();
		
		
		
		
		
		
		
	}
}
