
public class RadioRemote 
{
	public static ElectronicDevice getDevice()
	{
		return new Radio();
	}
}
