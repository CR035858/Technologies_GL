
public class TurnVolUp implements Command
{

	ElectronicDevice theDevice;
		public TurnVolUp(ElectronicDevice newDevice)
		{
			theDevice=newDevice;
		}
	@Override
	public void execute() {
		// TODO Auto-generated method stub
		theDevice.volumeUp();
		
	}

}
