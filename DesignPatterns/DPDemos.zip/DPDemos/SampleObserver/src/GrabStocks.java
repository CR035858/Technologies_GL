
public class GrabStocks {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//MAIN EXECUTION
		
		StockGrabber stockGrabber = new StockGrabber();//Subject - Observable - Publisher - register(observer)
		
		StockObserver observer1=new StockObserver(stockGrabber);// Observer - Subscriber - Listener
		
		stockGrabber.setAAPLPrice(677.60);
		stockGrabber.setIBMPrice(197.0);
		stockGrabber.setGOOGPrice(676.40);
		
		StockObserver observer2=new StockObserver(stockGrabber);
		
		stockGrabber.setAAPLPrice(777.60);
		stockGrabber.setIBMPrice(297.0);
		stockGrabber.setGOOGPrice(776.40);
		
		stockGrabber.unRegister(observer1);

		stockGrabber.setAAPLPrice(877.60);
		stockGrabber.setIBMPrice(397.0);
		stockGrabber.setGOOGPrice(876.40);

	}

}
