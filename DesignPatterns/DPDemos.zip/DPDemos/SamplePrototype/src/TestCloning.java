
public class TestCloning {
	
	public static void main(String[] args){
		
		// Handles routing makeCopy method calls to the 
		// right subclasses of Animal
		
		CloneFactory animalMaker = new CloneFactory();
		
		// Creates a new Sheep instance
		
		Sheep sally = new Sheep();
		
		// Creates a clone of Sally and stores it in its own
		// memory location
		//clonedSheep would have sally
		Sheep clonedSheep = (Sheep) animalMaker.getClone(sally);
		
		clonedSheep.myString="DollySheep";
		
		// These are exact copies of each other Q-A-W
		
		System.out.println(sally);
		
		System.out.println(clonedSheep);
		System.out.println("_--------------------------");
		System.out.println(sally);
		
		System.out.println("Sally HashCode: " + System.identityHashCode(System.identityHashCode(sally)));
		
		System.out.println("Clone HashCode: " + System.identityHashCode(System.identityHashCode(clonedSheep)));
		System.out.println("Sally HashCode: " + System.identityHashCode(System.identityHashCode(sally)));
		
		
		
		Sheep s1=new Sheep();
		s1.myString="Sally";
		
		Sheep s2=new Sheep();
		s2.myString="Dolly";
		s1=s2;
		System.out.println(s1);
		System.out.println(s2);
		
		System.out.println("S1 HashCode: " + System.identityHashCode(System.identityHashCode(s1)));
		
		System.out.println("S2 HashCode: " + System.identityHashCode(System.identityHashCode(s2)));
		
		
		
	}
	
}
