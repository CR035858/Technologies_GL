
public interface IStrategy {
	
	int getFinalBill(int billAmt);

}
