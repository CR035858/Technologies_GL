
public class LowDiscountStrategy implements IStrategy
{
	 public int getFinalBill(int billAmt)
     {
         return (int)(billAmt - (billAmt * 0.1));
     }
}
