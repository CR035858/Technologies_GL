
public class NoDiscountStrategy implements IStrategy
{
	 public int getFinalBill(int billAmt)
     {
         return billAmt;
     }
}
