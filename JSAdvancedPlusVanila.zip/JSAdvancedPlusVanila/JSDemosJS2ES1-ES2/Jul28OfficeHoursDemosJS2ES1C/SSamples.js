var num = 21;
var result = (num  == 0 )?'Zero':(num % 2 == 1 ? 'Odd' : 'Even');
console.log(result);