const days = [
    'Sun',
    'Mon',
    'Tue',
    'Wed'
];
for(let item of days)
{
    console.log(item);
}