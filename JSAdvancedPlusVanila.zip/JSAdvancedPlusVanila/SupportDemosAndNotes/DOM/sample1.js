function display()
{
alert("Welcome to External JS");
document.writeln("Welcome to External JS");
}