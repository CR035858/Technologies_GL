//IIFE Returning value
const someNum =(function(){
    return 100;
}());
console.log(someNum);
const sum = function(x,y){
return x + y;
};