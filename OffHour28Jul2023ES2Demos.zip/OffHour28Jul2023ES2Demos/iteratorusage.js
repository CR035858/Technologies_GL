var days = [
    {day: 'sunday',hours :2},
    {day: 'Monday',hours :8},
    {day: 'Tuesday',hours :7}
]

    days.forEach(function(item) {
        console.log(item);

    })


